FOOD PANTRY TRACKER - UPDATED VERSION

Files:
- app.py: Streamlit application
- requirements.txt: Python packages
- .streamlit/config.toml: forces the light theme

Run locally:
1. Open this folder in VS Code.
2. In the terminal run: python -m pip install -r requirements.txt
3. Run: python -m streamlit run app.py

IMPORTANT DATABASE NOTE:
The app stores items in food_pantry.db beside app.py. This gives consistent
storage across normal reruns on the same machine. Streamlit Community Cloud's
local filesystem is not guaranteed to persist across app restarts/redeployments.
For reliable long-term cloud storage, connect a hosted database such as Supabase.
Do not upload a database containing private information to a public repository.
